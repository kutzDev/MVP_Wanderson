Coloque aqui o PDF da proposta (CRM_Interno_MVP.pdf) e o diagrama do banco (dbdiagram).
