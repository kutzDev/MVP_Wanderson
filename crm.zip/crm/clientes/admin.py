from django.contrib import admin

from .models import Cliente, Interacao


@admin.register(Cliente)
class ClienteAdmin(admin.ModelAdmin):
    list_display = ("nome", "cidade", "loja_origem", "telefone", "criado_em")
    list_filter = ("loja_origem", "cidade")
    search_fields = ("nome", "cpf", "email")


@admin.register(Interacao)
class InteracaoAdmin(admin.ModelAdmin):
    list_display = ("cliente", "tipo", "usuario", "data_hora")
    list_filter = ("tipo",)
