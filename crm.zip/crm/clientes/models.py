from django.conf import settings
from django.db import models


class Cliente(models.Model):
    loja_origem = models.ForeignKey(
        "lojas.Loja", on_delete=models.PROTECT, related_name="clientes"
    )
    nome = models.CharField(max_length=100)
    cpf = models.CharField(max_length=11, unique=True, null=True, blank=True)
    telefone = models.CharField(max_length=20, blank=True)
    email = models.EmailField(max_length=120, blank=True)
    cidade = models.CharField(max_length=80)
    criado_em = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "clientes"
        ordering = ["nome"]

    def __str__(self):
        return self.nome


class Interacao(models.Model):
    class Tipo(models.TextChoices):
        LIGACAO = "ligacao", "Ligação"
        WHATSAPP = "whatsapp", "WhatsApp"
        EMAIL = "email", "E-mail"
        VISITA = "visita", "Visita"

    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE, related_name="interacoes")
    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="interacoes"
    )
    tipo = models.CharField(max_length=20, choices=Tipo.choices)
    descricao = models.TextField(blank=True)
    data_hora = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "interacoes"
        verbose_name = "interação"
        verbose_name_plural = "interações"
        ordering = ["-data_hora"]

    def __str__(self):
        return f"{self.get_tipo_display()} - {self.cliente}"
