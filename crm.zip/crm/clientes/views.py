from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, render

from contas.permissoes import lojas_visiveis

from .models import Cliente


@login_required
def lista(request):
    lojas = lojas_visiveis(request.user)
    clientes = Cliente.objects.filter(loja_origem__in=lojas).select_related("loja_origem")

    q = request.GET.get("q", "").strip()
    loja = request.GET.get("loja", "")
    cidade = request.GET.get("cidade", "").strip()
    if q:
        clientes = clientes.filter(nome__icontains=q)
    if loja:
        clientes = clientes.filter(loja_origem_id=loja)
    if cidade:
        clientes = clientes.filter(cidade__icontains=cidade)

    return render(request, "clientes/lista.html", {
        "clientes": clientes[:200],
        "lojas": lojas,
        "q": q, "loja_sel": loja, "cidade": cidade,
    })


@login_required
def detalhe(request, pk):
    cliente = get_object_or_404(
        Cliente, pk=pk, loja_origem__in=lojas_visiveis(request.user)
    )
    return render(request, "clientes/detalhe.html", {
        "cliente": cliente,
        "compras": cliente.vendas.select_related("loja", "vendedor")[:50],
        "interacoes": cliente.interacoes.select_related("usuario")[:50],
    })
