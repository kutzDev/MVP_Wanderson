from django.urls import path

from . import views

urlpatterns = [
    path("", views.lista, name="clientes"),
    path("<int:pk>/", views.detalhe, name="cliente_detalhe"),
]
