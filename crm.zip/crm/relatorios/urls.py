from django.urls import path

from . import views

urlpatterns = [
    path("", views.vendas_relatorio, name="relatorios"),
    path("vendas.csv", views.vendas_csv, name="relatorio_csv"),
]
