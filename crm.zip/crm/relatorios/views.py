import csv

from django.contrib.auth.decorators import login_required
from django.db.models import Count, Sum
from django.http import HttpResponse
from django.shortcuts import render

from contas.permissoes import perfil_requerido
from vendas.filtros import filtrar_vendas

PERFIS = ("Chefe", "Contabilidade", "Tecnologia")


@login_required
@perfil_requerido(*PERFIS)
def vendas_relatorio(request):
    vendas, lojas, sel = filtrar_vendas(request)
    resumo = (
        vendas.values("loja__nome")
        .annotate(qtd=Count("id"), total=Sum("valor_total"))
        .order_by("loja__nome")
    )
    total = vendas.aggregate(t=Sum("valor_total"))["t"] or 0
    return render(request, "relatorios/vendas.html", {
        "resumo": resumo, "total": total, "lojas": lojas, "sel": sel,
        "querystring": request.GET.urlencode(),
    })


@login_required
@perfil_requerido(*PERFIS)
def vendas_csv(request):
    vendas, _, _ = filtrar_vendas(request)
    resposta = HttpResponse(content_type="text/csv; charset=utf-8")
    resposta["Content-Disposition"] = 'attachment; filename="relatorio_vendas.csv"'
    resposta.write("\ufeff")  # BOM para o Excel abrir acentos corretamente
    w = csv.writer(resposta, delimiter=";")
    w.writerow(["Data", "Loja", "Vendedor", "Cliente", "Pagamento", "Valor"])
    for v in vendas:
        w.writerow([
            v.data_venda.strftime("%d/%m/%Y %H:%M"), v.loja.nome, v.vendedor.nome,
            v.cliente.nome, v.forma_pagamento, str(v.valor_total).replace(".", ","),
        ])
    return resposta
