from django.db import migrations

PERFIS = ["Chefe", "Gerente de Loja", "Tecnologia", "Contabilidade"]


def criar_perfis(apps, schema_editor):
    Perfil = apps.get_model("contas", "Perfil")
    for nome in PERFIS:
        Perfil.objects.get_or_create(nome=nome)


class Migration(migrations.Migration):
    dependencies = [("contas", "0001_initial")]
    operations = [migrations.RunPython(criar_perfis, migrations.RunPython.noop)]
