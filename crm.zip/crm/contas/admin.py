from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import Perfil, Usuario

admin.site.register(Perfil)


@admin.register(Usuario)
class CustomUserAdmin(UserAdmin):
    list_display = ("username", "nome", "email", "perfil", "loja", "is_active")
    fieldsets = UserAdmin.fieldsets + (("CRM", {"fields": ("nome", "perfil", "loja")}),)
    add_fieldsets = UserAdmin.add_fieldsets + (
        ("CRM", {"fields": ("nome", "email", "perfil", "loja")}),
    )
