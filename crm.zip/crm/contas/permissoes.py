from functools import wraps

from django.core.exceptions import PermissionDenied

from lojas.models import Loja


def lojas_visiveis(user):
    """Gerente de Loja só enxerga a própria loja; Chefe/Tecnologia/Contabilidade veem todas."""
    if user.ve_todas_lojas:
        return Loja.objects.all()
    if user.loja_id:
        return Loja.objects.filter(pk=user.loja_id)
    return Loja.objects.none()


def perfil_requerido(*perfis):
    """Libera a view só para os perfis informados (superusuário sempre passa)."""
    def decorador(view):
        @wraps(view)
        def wrapper(request, *args, **kwargs):
            u = request.user
            if u.is_superuser or u.nome_perfil in perfis:
                return view(request, *args, **kwargs)
            raise PermissionDenied
        return wrapper
    return decorador
