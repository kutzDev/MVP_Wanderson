from django.contrib.auth.models import AbstractUser
from django.db import models


class Perfil(models.Model):
    nome = models.CharField(max_length=30, unique=True)

    class Meta:
        db_table = "perfis"
        verbose_name_plural = "perfis"

    def __str__(self):
        return self.nome


class Usuario(AbstractUser):
    # password (hash), is_active e date_joined já vêm do AbstractUser
    # (equivalem a senha_hash, ativo e criado_em do diagrama)
    nome = models.CharField(max_length=100)
    email = models.EmailField(max_length=120, unique=True)
    perfil = models.ForeignKey(
        Perfil, on_delete=models.PROTECT, related_name="usuarios", null=True, blank=True
    )
    loja = models.ForeignKey(
        "lojas.Loja", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="usuarios",
    )

    class Meta:
        db_table = "usuarios"

    def __str__(self):
        return self.nome or self.username

    # atalhos de permissão por perfil
    @property
    def nome_perfil(self):
        return self.perfil.nome if self.perfil else ""

    @property
    def ve_todas_lojas(self):
        return self.is_superuser or self.nome_perfil in ("Chefe", "Tecnologia", "Contabilidade")
