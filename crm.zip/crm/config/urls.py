from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("contas.urls")),
    path("", include("dashboard.urls")),
    path("clientes/", include("clientes.urls")),
    path("vendas/", include("vendas.urls")),
    path("relatorios/", include("relatorios.urls")),
]
