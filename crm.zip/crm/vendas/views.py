from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.shortcuts import render

from lojas.models import Vendedor

from .filtros import filtrar_vendas


@login_required
def lista(request):
    vendas, lojas, sel = filtrar_vendas(request)
    total = vendas.aggregate(t=Sum("valor_total"))["t"] or 0
    return render(request, "vendas/lista.html", {
        "vendas": vendas[:200],
        "total": total,
        "lojas": lojas,
        "vendedores": Vendedor.objects.filter(loja__in=lojas),
        "sel": sel,
    })
