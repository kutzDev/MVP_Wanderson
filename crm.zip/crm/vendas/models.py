from django.db import models


class Venda(models.Model):
    vendedor = models.ForeignKey("lojas.Vendedor", on_delete=models.PROTECT, related_name="vendas")
    loja = models.ForeignKey("lojas.Loja", on_delete=models.PROTECT, related_name="vendas")
    cliente = models.ForeignKey("clientes.Cliente", on_delete=models.PROTECT, related_name="vendas")
    data_venda = models.DateTimeField()
    valor_total = models.DecimalField(max_digits=12, decimal_places=2)
    forma_pagamento = models.CharField(max_length=20)

    class Meta:
        db_table = "vendas"
        ordering = ["-data_venda"]

    def __str__(self):
        return f"Venda {self.pk} - {self.loja}"
