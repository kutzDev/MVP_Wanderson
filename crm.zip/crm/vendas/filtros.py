from contas.permissoes import lojas_visiveis

from .models import Venda


def filtrar_vendas(request):
    """Filtros compartilhados entre a tela de vendas e os relatórios."""
    lojas = lojas_visiveis(request.user)
    vendas = Venda.objects.filter(loja__in=lojas).select_related("loja", "cliente", "vendedor")

    loja = request.GET.get("loja", "")
    vendedor = request.GET.get("vendedor", "")
    inicio = request.GET.get("inicio", "")
    fim = request.GET.get("fim", "")

    if loja:
        vendas = vendas.filter(loja_id=loja)
    if vendedor:
        vendas = vendas.filter(vendedor_id=vendedor)
    if inicio:
        vendas = vendas.filter(data_venda__date__gte=inicio)
    if fim:
        vendas = vendas.filter(data_venda__date__lte=fim)

    return vendas, lojas, {"loja": loja, "vendedor": vendedor, "inicio": inicio, "fim": fim}
