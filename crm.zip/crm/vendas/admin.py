from django.contrib import admin

from .models import Venda


@admin.register(Venda)
class VendaAdmin(admin.ModelAdmin):
    list_display = ("id", "loja", "vendedor", "cliente", "valor_total", "forma_pagamento", "data_venda")
    list_filter = ("loja", "forma_pagamento")
    date_hierarchy = "data_venda"
