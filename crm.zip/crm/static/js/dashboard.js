const lojas = JSON.parse(document.getElementById("dados-lojas").textContent);
const meses = JSON.parse(document.getElementById("dados-mes").textContent);

const reais = (v) => "R$ " + Number(v).toLocaleString("pt-BR", { minimumFractionDigits: 2 });
const opcoes = {
  plugins: { legend: { display: false }, tooltip: { callbacks: { label: (c) => reais(c.parsed.y ?? c.parsed.x) } } },
  scales: { y: { beginAtZero: true, ticks: { callback: (v) => reais(v) } } },
};

new Chart(document.getElementById("graficoLojas"), {
  type: "bar",
  data: { labels: lojas.labels, datasets: [{ data: lojas.valores, backgroundColor: "#2f7d6d", borderRadius: 3 }] },
  options: opcoes,
});

new Chart(document.getElementById("graficoMes"), {
  type: "line",
  data: { labels: meses.labels, datasets: [{ data: meses.valores, borderColor: "#c2792e", backgroundColor: "#c2792e", tension: 0.25 }] },
  options: opcoes,
});
