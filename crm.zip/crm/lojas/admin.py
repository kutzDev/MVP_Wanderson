from django.contrib import admin

from .models import Loja, Vendedor


@admin.register(Loja)
class LojaAdmin(admin.ModelAdmin):
    list_display = ("nome", "cidade", "uf", "shopping", "ativa")
    list_filter = ("uf", "ativa")
    search_fields = ("nome", "cidade")


@admin.register(Vendedor)
class VendedorAdmin(admin.ModelAdmin):
    list_display = ("nome", "loja", "ativo")
    list_filter = ("loja", "ativo")
