from django.db import models


class Loja(models.Model):
    nome = models.CharField(max_length=100, unique=True)
    cidade = models.CharField(max_length=80)
    shopping = models.CharField(max_length=80)
    uf = models.CharField(max_length=2)
    ativa = models.BooleanField(default=True)

    class Meta:
        db_table = "lojas"

    def __str__(self):
        return self.nome


class Vendedor(models.Model):
    loja = models.ForeignKey(Loja, on_delete=models.PROTECT, related_name="vendedores")
    nome = models.CharField(max_length=100)
    ativo = models.BooleanField(default=True)

    class Meta:
        db_table = "vendedores"
        verbose_name_plural = "vendedores"

    def __str__(self):
        return self.nome
