from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.db.models.functions import TruncMonth
from django.shortcuts import render

from clientes.models import Cliente
from contas.permissoes import lojas_visiveis
from vendas.models import Venda


@login_required
def home(request):
    lojas = lojas_visiveis(request.user)
    vendas = Venda.objects.filter(loja__in=lojas)
    clientes = Cliente.objects.filter(loja_origem__in=lojas)

    por_loja = (
        vendas.values("loja__nome").annotate(total=Sum("valor_total")).order_by("-total")
    )
    por_mes = (
        vendas.annotate(mes=TruncMonth("data_venda"))
        .values("mes").annotate(total=Sum("valor_total")).order_by("mes")
    )

    contexto = {
        "total_vendas": vendas.aggregate(t=Sum("valor_total"))["t"] or 0,
        "qtd_vendas": vendas.count(),
        "total_clientes": clientes.count(),
        "total_lojas": lojas.filter(ativa=True).count(),
        "grafico_lojas": {
            "labels": [x["loja__nome"] for x in por_loja],
            "valores": [float(x["total"]) for x in por_loja],
        },
        "grafico_mes": {
            "labels": [x["mes"].strftime("%m/%Y") for x in por_mes],
            "valores": [float(x["total"]) for x in por_mes],
        },
        "ultimas_vendas": vendas.select_related("loja", "cliente", "vendedor")[:8],
    }
    return render(request, "dashboard/home.html", contexto)
