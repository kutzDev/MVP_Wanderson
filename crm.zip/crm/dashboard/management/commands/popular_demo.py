import random
from datetime import timedelta
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.utils import timezone

from clientes.models import Cliente, Interacao
from contas.models import Perfil, Usuario
from lojas.models import Loja, Vendedor
from vendas.models import Venda


class Command(BaseCommand):
    help = "Cria lojas, vendedores, clientes, vendas e usuários de exemplo para testar o CRM."

    def handle(self, *args, **opts):
        random.seed(7)
        lojas_info = [
            ("Vitória Centro", "Vitória", "Praia do Canto", "ES"),
            ("Vila Velha Shopping", "Vila Velha", "Shopping Vila Velha", "ES"),
            ("Serra Mall", "Serra", "Shopping Montserrat", "ES"),
            ("Niterói Plaza", "Niterói", "Plaza Shopping", "RJ"),
            ("Rio Barra", "Rio de Janeiro", "Barra Shopping", "RJ"),
        ]
        lojas = [
            Loja.objects.get_or_create(nome=n, defaults=dict(cidade=c, shopping=s, uf=u))[0]
            for n, c, s, u in lojas_info
        ]

        nomes = ["Ana", "Bruno", "Carla", "Diego", "Elisa", "Fábio", "Gabriela", "Hugo", "Isabela", "João"]
        sobrenomes = ["Silva", "Souza", "Costa", "Almeida", "Rocha", "Pereira", "Lima", "Gomes"]

        vendedores = {}
        for loja in lojas:
            vendedores[loja.id] = [
                Vendedor.objects.get_or_create(loja=loja, nome=f"{random.choice(nomes)} {random.choice(sobrenomes)}")[0]
                for _ in range(3)
            ]

        perfis = {p.nome: p for p in Perfil.objects.all()}
        usuarios = [
            ("chefe", "Chefe Demo", "Chefe", None),
            ("gerente", "Gerente Vitória", "Gerente de Loja", lojas[0]),
            ("contabil", "Contabilidade Demo", "Contabilidade", None),
            ("ti", "Tecnologia Demo", "Tecnologia", None),
        ]
        for username, nome, perfil, loja in usuarios:
            if not Usuario.objects.filter(username=username).exists():
                Usuario.objects.create_user(
                    username=username, password="crm12345", nome=nome,
                    email=f"{username}@demo.local", perfil=perfis.get(perfil), loja=loja,
                    is_staff=(perfil == "Tecnologia"),
                )
        atendente = Usuario.objects.get(username="chefe")

        if Cliente.objects.exists():
            self.stdout.write("Já existem clientes; pulando a criação de clientes e vendas.")
            return

        agora = timezone.now()
        formas = ["Cartão", "Pix", "Dinheiro", "Débito"]
        for loja in lojas:
            for i in range(12):
                cliente = Cliente.objects.create(
                    loja_origem=loja,
                    nome=f"{random.choice(nomes)} {random.choice(sobrenomes)} {loja.id}{i}",
                    telefone=f"2799{random.randint(1000000, 9999999)}",
                    email=f"cliente{loja.id}{i}@exemplo.com",
                    cidade=loja.cidade,
                )
                Interacao.objects.create(
                    cliente=cliente, usuario=atendente,
                    tipo=random.choice(Interacao.Tipo.values), descricao="Contato de relacionamento (demo).",
                )
                for _ in range(random.randint(1, 4)):
                    Venda.objects.create(
                        vendedor=random.choice(vendedores[loja.id]), loja=loja, cliente=cliente,
                        data_venda=agora - timedelta(days=random.randint(0, 150)),
                        valor_total=Decimal(random.randint(8000, 90000)) / 100,
                        forma_pagamento=random.choice(formas),
                    )
        self.stdout.write(self.style.SUCCESS(
            "Dados de exemplo criados. Logins (senha crm12345): chefe, gerente, contabil, ti"
        ))
